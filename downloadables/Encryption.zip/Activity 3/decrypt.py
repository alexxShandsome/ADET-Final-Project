#!/usr/bin/env python3

import sys
import os
from caesar import caesar_decrypt
from animation import status_animation

# print help and instructions
if sys.argv[1] == "help" or sys.argv[1] == "--help" or sys.argv[1] == "-h":
    os.system("cat help.txt")
    exit()

file_to_decrypt = sys.argv[1]
option = sys.argv[2]
secret_key = sys.argv[3]

if option == "-key":
    file = open(file_to_decrypt, "r")
    file_content = file.read()
    # print("File Content:\n" + file_content)
    file_content = caesar_decrypt(file_content, int(secret_key))

    # play animation
    print("Decrypting...\n")
    status_animation()
    print("File Successfully Decrypted")

    file = open(file_to_decrypt, "w")
    file.write(file_content)

    # remove the .crypt file extension
    new_file_name = file_to_decrypt.replace(".crypt", "")

    # rename the file inside the directory
    os.rename(file_to_decrypt, new_file_name)

    file.close()

else:
    print("have a nice day")
    exit()
