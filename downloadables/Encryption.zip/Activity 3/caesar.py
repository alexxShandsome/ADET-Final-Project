def caesar_encrypt(plaintext, shift):
    ciphertext = ""
    for char in plaintext:
        shift_char = chr(ord(char) + shift)
        ciphertext += shift_char

    return ciphertext

def caesar_decrypt(ciphertext, shift):
    plaintext = ""
    for char in ciphertext:
        shift_char = chr(ord(char) - shift)
        plaintext += shift_char

    return plaintext

