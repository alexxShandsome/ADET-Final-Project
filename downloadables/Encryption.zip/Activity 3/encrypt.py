#!/usr/bin/env python3

import sys
import os
from caesar import caesar_encrypt
from animation import status_animation

# print help and instructions
if sys.argv[1] == "help" or sys.argv[1] == "--help" or sys.argv[1] == "-h":
    os.system("cat help.txt")
    exit()

file_to_encrypt = sys.argv[1]
option = sys.argv[2]
secret_key = sys.argv[3]

if option == "-key":
    file = open(file_to_encrypt, "r")
    file_content = file.read()
    file_content = caesar_encrypt(file_content, int(secret_key))

    # play animation
    print("Encrypting...\n")
    status_animation()
    print("File Successfully Encrypted")

    file = open(file_to_encrypt, "w")
    file.write(file_content)

    # concatenate .crypt to the file to be encrypt
    new_file_name = file_to_encrypt + ".crypt"

    # rename the file inside the directory
    os.rename(file_to_encrypt, new_file_name)

    file.close()

else:
    print("have a nice day")
    exit()
