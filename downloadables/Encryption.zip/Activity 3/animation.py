import time

# for status bar animation
def status_animation():
    for i in range(1, 41):
        status_bar = f"[{'*' * i}{' ' * (40 - i)}]"
        print(status_bar, end="\r")
        time.sleep(0.1)

    # Clear the status bar
    print("\033[K", end="\r")
# end of status_animation()

