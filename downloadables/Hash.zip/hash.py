def hashedString(stringInput):
    hash = 123456789
    prime = 98765432

    for i in stringInput:
        hash = (hash * prime) ^ ord(i)

    return format(hash & 0xffffffff, "x")

while True:
    userString = input("> ")
    print(hashedString(userString))
